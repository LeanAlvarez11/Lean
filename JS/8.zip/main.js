console.log ("Starting Javascrip...");
var myname="leandro";
console.log (myname);
var age=31;
console.log (age);
var ignasiage=32;
var agediff=age-ignasiage;
console.log (agediff);
if (age>21)
	{
		console.log ("tiene mas de 21 años")           
	}
else 																				
	{																//compara mi edad con 21 años
		console.log ("no tiene mas de 21 años")
	}
if (age<ignasiage)
	{
		console.log ("ignasi es mayor que usted")
	}
else if (age>ignasiage)
	{
		console.log ("ignasi es menor que usted")					//compara mi edad con la de ignasi
	}
else
	{
		console.log ("tiene la misma edad que ignasi")
	}


var names = ["nahu","alan","diego","ariel","lean"]
names.sort();		
console.log ("primer elemento: ",names[0]," ultimo elemento: ",names[names.length-1])												//ordena alfabeticamente el vector
console.log (names);
var edades = [14,15,12,24,19,14];
for (var i=0;i<5;i++)
	{
		if (edades[i]%2==0)
			{														
				console.log (edades[i]);
			}
	}
function mostrarmenor (array)
	{																//crea una funcion para que muestre el menor de un vector
		var cont = array[0];
		for (var i=1; i<array.length;i++)
			{
				if (array[i]<cont)
					{
						cont = array [i]
					}
			}
		console.log (cont);
	}
mostrarmenor (edades);
function mostrarmayor (array)
	{																//crea una funcion para que muestre el mayor de un vector
		var cont = array[0];
		for (var i=1; i<array.length;i++)
			{
				if (array[i]>cont)
					{
						cont = array [i]
					}
			}
		console.log (cont);
	}
mostrarmayor (edades);
var ejem = [3,6,6,6,2,11,100,8,93,0,17,24,7,1,33,45,28,33,23,12,99,100];
function mostrarindice (array,i)
	{
		if (i<array.length)
		{
		console.log (array[i]);										//crea una funcion que muestre un array con un indice indicado
		}
		else
			console.log ("error")
	}
mostrarindice (ejem,1);
function repetidos (array)
	{
		let aux=[];
		for (var i=0;i<array.length;i++)
			{
				for (var j=i+1;j<array.length;j++)					//crea una funcion que muestre los numeros repetidos
					{
						if (array[j]==array[i] && aux.indexOf(array[i])==-1)
							{
								aux.push(array[i])
							}
					}
			}
		console.log(aux)
	}
repetidos (ejem);
function repetidos2 (array)
	{
		let aux=[];
		for (var i=0;i<array.length;i++)
			{
				if (array.indexOf(array[i],i+1)!= -1 && aux.indexOf(array[i])==-1) //muestra los repetidos 2
					{
						aux.push(array[i])
					}
			}
		console.log(aux)
	}
repetidos2 (ejem);
myColor = ["Red", "Green", "White", "Black"];
function arraytostring (array)
	{
		var x = array.toString()								//crea una funcion que convierta un array en un string
		console.log (x);
	}
arraytostring (myColor);


var cadena=1234;
function invertir(int) 
	{
	  var string = int.toString();
	  var cadenaInvertida = "";
	  for (var 	i=string.length-1;i>=0;i--)
	   	{
		    cadenaInvertida += string[i];	//funcion que invierte una string
		}
	    console.log (+cadenaInvertida);
	  }
invertir (cadena);
var  ejem2="hola";
function ordenar (string)
 	{		
 		console.log (string.split("").sort().toString().replace(/,/g,""));
 		//ordena alfabeticamente un string
 		//replace () remplaza algo "(/o/g" por otra cosa ","a")"
 	}	
ordenar (ejem2);
var ejem3 = "hola como estas"; 
function mayusculas (string)
	{
		var vec=string.split (" ");
		for (var i=0;i<vec.length;i++)
			{
				vec[i]=vec[i].charAt(0).toUpperCase() + vec[i].slice(1);  //convierte la primer letra de cada palabra en mayuscula
			}
			string = vec.toString();
			string = string.replace(/,/g, " ");
			console.log (string)
	}
mayusculas (ejem3);
function mayusculas2 (string)
	{
		console.log (string.replace(/\b[a-z]/g, l=>l.toUpperCase()))     //\b\[a-z] los numeros iniciales de la a a la z
	}
var ejem4="lo que pega el pyke hermano alto crack"
mayusculas2 (ejem4)
function maslarga (string)
	{
		var grande="";
		var vec=string.split (" ");
		vec.forEach (
			function (palabra)
				{
					if (palabra.length>grande.length)		//funcion para encontrar la palabra mas grande de un string
						{
							grande=palabra;
						}
				})
		console.log (grande);
	}
maslarga (ejem4);	

	


  // document.getElementById("senate-data").innerHTML=JSON.stringify(data,null,2);
            const tbody = document.querySelector ("tbody")
            const members = data.results[0].members
            members.forEach( member => {
                let row = tbody.insertRow (-1);
                row.innerHTML =`
                <td> <a href="${member.url}">${member.first_name} ${member.middle_name || ""} ${member.last_name}<a> </td>
                <td> ${member.party}</td>
                <td> ${member.state}</td>
                <td> ${member.seniority}</td>
                <td> ${member.votes_with_party_pct}\%</td>`
            })